# Check Image

Script to visually check image quality. A 3x3 preview crop will be created.

## Usage

* open image

![M31 full](img/M31_full.JPG "Example M31 full")

* execute script Devgroup/Checkimage

![M31 cropped](img/M31_cropped_3x3.jpg "3x3 crop of full image")

